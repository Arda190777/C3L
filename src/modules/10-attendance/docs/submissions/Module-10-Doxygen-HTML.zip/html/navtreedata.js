/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "C3L Module 10 - Attendance", "index.html", [
    [ "Module 10 - Sprint 1 design", "index.html", "index" ],
    [ "Module 10 - SRS update proposal", "md_src_2modules_210-attendance_2docs_2srs-update.html", [
      [ "Problem and scope", "md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12", null ],
      [ "User stories", "md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md13", null ],
      [ "Planned team responsibility", "md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14", null ],
      [ "Business rules and dependencies", "md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md15", null ]
    ] ],
    [ "Sprint 1 test results", "md_src_2modules_210-attendance_2docs_2testing.html", [
      [ "Automated results", "md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md17", null ],
      [ "Cases and traceability", "md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md18", null ],
      [ "Browser checks", "md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md19", null ],
      [ "Defect and integration log", "md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md20", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Variables", "globals_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

const SYNCONMSG = 'click to disable panel synchronization';
const SYNCOFFMSG = 'click to enable panel synchronization';
const LISTOFALLMEMBERS = 'List of all members';