var index =
[
    [ "Architecture", "index.html#autotoc_md1", null ],
    [ "Use cases", "index.html#autotoc_md2", null ],
    [ "Class and responsibilities", "index.html#autotoc_md3", null ],
    [ "Database design", "index.html#autotoc_md4", null ],
    [ "HTML routes", "index.html#autotoc_md5", null ],
    [ "JSON API", "index.html#autotoc_md6", [
      [ "POST /10-attendance/api/attendance", "index.html#autotoc_md7", null ],
      [ "GET /10-attendance/api/attendance", "index.html#autotoc_md8", null ]
    ] ],
    [ "Limits and decisions", "index.html#autotoc_md9", null ],
    [ "Source files", "index.html#autotoc_md10", null ]
];