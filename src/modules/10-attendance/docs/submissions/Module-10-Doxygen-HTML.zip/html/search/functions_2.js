var searchData=
[
  ['list_0',['list',['../class_attendance_store.html#a1d932295efbd7c018bd1984ddec47550',1,'AttendanceStore']]]
];
