var indexSectionsWithContent =
{
  0: "1abcdfghijlmnprstu",
  1: "a",
  2: "adiprst",
  3: "cdls",
  4: "cdins",
  5: "1abcdfghijlmprstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

