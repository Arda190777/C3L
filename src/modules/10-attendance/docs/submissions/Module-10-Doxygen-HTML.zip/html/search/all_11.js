var searchData=
[
  ['update_20proposal_0',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]],
  ['use_20cases_1',['Use cases',['../index.html#autotoc_md2',1,'']]],
  ['user_20stories_2',['User stories',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md13',1,'']]]
];
