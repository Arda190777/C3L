var searchData=
[
  ['courseid_0',['courseId',['../store_8js.html#ae2cf3bc09ea71584b06a372841edb72a',1,'store.js']]]
];
