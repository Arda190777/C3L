var searchData=
[
  ['and_20decisions_0',['Limits and decisions',['../index.html#autotoc_md9',1,'']]],
  ['and_20dependencies_1',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]],
  ['and_20integration_20log_2',['Defect and integration log',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md19',1,'']]],
  ['and_20responsibilities_3',['Class and responsibilities',['../index.html#autotoc_md3',1,'']]],
  ['and_20scope_4',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['and_20traceability_5',['Cases and traceability',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md17',1,'']]],
  ['api_6',['JSON API',['../index.html#autotoc_md6',1,'']]],
  ['api_20attendance_7',['api attendance',['../index.html#autotoc_md8',1,'GET /10-attendance/api/attendance'],['../index.html#autotoc_md7',1,'POST /10-attendance/api/attendance']]],
  ['architecture_8',['Architecture',['../index.html#autotoc_md1',1,'']]],
  ['attendance_9',['attendance',['../index.html#autotoc_md8',1,'GET /10-attendance/api/attendance'],['../index.html#autotoc_md7',1,'POST /10-attendance/api/attendance']]],
  ['attendance_20api_20attendance_10',['attendance api attendance',['../index.html#autotoc_md8',1,'GET /10-attendance/api/attendance'],['../index.html#autotoc_md7',1,'POST /10-attendance/api/attendance']]],
  ['automated_20results_11',['Automated results',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md16',1,'']]]
];
