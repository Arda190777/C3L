var searchData=
[
  ['date_0',['date',['../store_8js.html#a17c42a345ea2516551cb82a290b8d586',1,'store.js']]]
];
