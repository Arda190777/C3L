var searchData=
[
  ['status_0',['status',['../store_8js.html#a52780be446fa8721e1042a757dbe4615',1,'store.js']]],
  ['studentid_1',['studentId',['../store_8js.html#a4ab28e41ef28c0de08cf3d772e1116f4',1,'store.js']]]
];
