var searchData=
[
  ['pages_2ejs_0',['pages.js',['../pages_8js.html',1,'']]]
];
