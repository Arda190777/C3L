var searchData=
[
  ['limits_20and_20decisions_0',['Limits and decisions',['../index.html#autotoc_md9',1,'']]],
  ['list_1',['list',['../class_attendance_store.html#a1d932295efbd7c018bd1984ddec47550',1,'AttendanceStore']]],
  ['log_2',['Defect and integration log',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md20',1,'']]]
];
