var searchData=
[
  ['get_2010_20attendance_20api_20attendance_0',['GET /10-attendance/api/attendance',['../index.html#autotoc_md8',1,'']]]
];
