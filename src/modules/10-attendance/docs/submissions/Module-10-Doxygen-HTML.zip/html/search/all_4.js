var searchData=
[
  ['database_20design_0',['Database design',['../index.html#autotoc_md4',1,'']]],
  ['date_1',['date',['../store_8js.html#a17c42a345ea2516551cb82a290b8d586',1,'store.js']]],
  ['db_2',['db',['../class_attendance_store.html#a1677cdeb0f6c4d672939a4193dede5a3',1,'AttendanceStore']]],
  ['decisions_3',['Limits and decisions',['../index.html#autotoc_md9',1,'']]],
  ['defect_20and_20integration_20log_4',['Defect and integration log',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md20',1,'']]],
  ['dependencies_5',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md15',1,'']]],
  ['design_6',['design',['../index.html#autotoc_md4',1,'Database design'],['../index.html',1,'Module 10 - Sprint 1 design']]],
  ['design_2emd_7',['design.md',['../design_8md.html',1,'']]]
];
