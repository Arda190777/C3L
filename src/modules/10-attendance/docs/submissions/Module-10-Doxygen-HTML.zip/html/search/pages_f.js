var searchData=
[
  ['team_20responsibility_0',['Planned team responsibility',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]],
  ['test_20results_1',['Sprint 1 test results',['../md_src_2modules_210-attendance_2docs_2testing.html',1,'']]],
  ['traceability_2',['Cases and traceability',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md18',1,'']]]
];
