var searchData=
[
  ['scope_0',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['source_20files_1',['Source files',['../index.html#autotoc_md10',1,'']]],
  ['sprint_201_20design_2',['Module 10 - Sprint 1 design',['../index.html',1,'']]],
  ['sprint_201_20test_20results_3',['Sprint 1 test results',['../md_src_2modules_210-attendance_2docs_2testing.html',1,'']]],
  ['srs_20update_20proposal_4',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]],
  ['stories_5',['User stories',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md13',1,'']]]
];
