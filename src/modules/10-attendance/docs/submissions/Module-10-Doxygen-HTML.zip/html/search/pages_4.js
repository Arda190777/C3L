var searchData=
[
  ['database_20design_0',['Database design',['../index.html#autotoc_md4',1,'']]],
  ['decisions_1',['Limits and decisions',['../index.html#autotoc_md9',1,'']]],
  ['defect_20and_20integration_20log_2',['Defect and integration log',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md20',1,'']]],
  ['dependencies_3',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md15',1,'']]],
  ['design_4',['design',['../index.html#autotoc_md4',1,'Database design'],['../index.html',1,'Module 10 - Sprint 1 design']]]
];
