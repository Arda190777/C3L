var searchData=
[
  ['router_2ejs_0',['router.js',['../router_8js.html',1,'']]]
];
