var searchData=
[
  ['post_2010_20attendance_20api_20attendance_0',['POST /10-attendance/api/attendance',['../index.html#autotoc_md7',1,'']]],
  ['problem_20and_20scope_1',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['proposal_2',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]]
];
