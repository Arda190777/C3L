var searchData=
[
  ['planned_20team_20responsibility_0',['Planned team responsibility',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]],
  ['post_2010_20attendance_20api_20attendance_1',['POST /10-attendance/api/attendance',['../index.html#autotoc_md7',1,'']]],
  ['problem_20and_20scope_2',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['proposal_3',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]]
];
