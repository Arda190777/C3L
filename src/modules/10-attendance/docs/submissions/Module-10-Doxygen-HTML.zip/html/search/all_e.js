var searchData=
[
  ['responsibilities_0',['Class and responsibilities',['../index.html#autotoc_md3',1,'']]],
  ['responsibility_1',['Planned team responsibility',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]],
  ['results_2',['results',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md17',1,'Automated results'],['../md_src_2modules_210-attendance_2docs_2testing.html',1,'Sprint 1 test results']]],
  ['router_2ejs_3',['router.js',['../router_8js.html',1,'']]],
  ['routes_4',['HTML routes',['../index.html#autotoc_md5',1,'']]],
  ['rules_20and_20dependencies_5',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md15',1,'']]]
];
