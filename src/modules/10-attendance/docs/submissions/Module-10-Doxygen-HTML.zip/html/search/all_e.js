var searchData=
[
  ['responsibilities_0',['Class and responsibilities',['../index.html#autotoc_md3',1,'']]],
  ['results_1',['results',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md16',1,'Automated results'],['../md_src_2modules_210-attendance_2docs_2testing.html',1,'Sprint 1 test results']]],
  ['router_2ejs_2',['router.js',['../router_8js.html',1,'']]],
  ['routes_3',['HTML routes',['../index.html#autotoc_md5',1,'']]],
  ['rules_20and_20dependencies_4',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]]
];
