var searchData=
[
  ['cases_0',['Use cases',['../index.html#autotoc_md2',1,'']]],
  ['cases_20and_20traceability_1',['Cases and traceability',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md18',1,'']]],
  ['checks_2',['Browser checks',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md19',1,'']]],
  ['class_20and_20responsibilities_3',['Class and responsibilities',['../index.html#autotoc_md3',1,'']]]
];
