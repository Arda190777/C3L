var searchData=
[
  ['browser_20checks_0',['Browser checks',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md19',1,'']]],
  ['business_20rules_20and_20dependencies_1',['Business rules and dependencies',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md15',1,'']]]
];
