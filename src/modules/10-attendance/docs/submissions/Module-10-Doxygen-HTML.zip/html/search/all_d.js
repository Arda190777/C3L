var searchData=
[
  ['pages_2ejs_0',['pages.js',['../pages_8js.html',1,'']]],
  ['planned_20team_20responsibility_1',['Planned team responsibility',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md14',1,'']]],
  ['post_2010_20attendance_20api_20attendance_2',['POST /10-attendance/api/attendance',['../index.html#autotoc_md7',1,'']]],
  ['problem_20and_20scope_3',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['proposal_4',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]]
];
