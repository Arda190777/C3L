var searchData=
[
  ['limits_20and_20decisions_0',['Limits and decisions',['../index.html#autotoc_md9',1,'']]],
  ['log_1',['Defect and integration log',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md19',1,'']]]
];
