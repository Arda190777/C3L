var searchData=
[
  ['save_0',['save',['../class_attendance_store.html#a28867943fd27dfe07d5e45f8cc852f4f',1,'AttendanceStore']]],
  ['scope_1',['Problem and scope',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md12',1,'']]],
  ['source_20files_2',['Source files',['../index.html#autotoc_md10',1,'']]],
  ['sprint_201_20design_3',['Module 10 - Sprint 1 design',['../index.html',1,'']]],
  ['sprint_201_20test_20results_4',['Sprint 1 test results',['../md_src_2modules_210-attendance_2docs_2testing.html',1,'']]],
  ['srs_20update_20proposal_5',['Module 10 - SRS update proposal',['../md_src_2modules_210-attendance_2docs_2srs-update.html',1,'']]],
  ['srs_2dupdate_2emd_6',['srs-update.md',['../srs-update_8md.html',1,'']]],
  ['status_7',['status',['../store_8js.html#a52780be446fa8721e1042a757dbe4615',1,'store.js']]],
  ['store_2ejs_8',['store.js',['../store_8js.html',1,'']]],
  ['stories_9',['User stories',['../md_src_2modules_210-attendance_2docs_2srs-update.html#autotoc_md13',1,'']]],
  ['studentid_10',['studentId',['../store_8js.html#a4ab28e41ef28c0de08cf3d772e1116f4',1,'store.js']]]
];
