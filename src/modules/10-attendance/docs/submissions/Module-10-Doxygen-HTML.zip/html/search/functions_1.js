var searchData=
[
  ['db_0',['db',['../class_attendance_store.html#a1677cdeb0f6c4d672939a4193dede5a3',1,'AttendanceStore']]]
];
