var searchData=
[
  ['cases_0',['Use cases',['../index.html#autotoc_md2',1,'']]],
  ['cases_20and_20traceability_1',['Cases and traceability',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md17',1,'']]],
  ['checks_2',['Browser checks',['../md_src_2modules_210-attendance_2docs_2testing.html#autotoc_md18',1,'']]],
  ['class_20and_20responsibilities_3',['Class and responsibilities',['../index.html#autotoc_md3',1,'']]],
  ['close_4',['close',['../class_attendance_store.html#af447fcffcf5fa416b305c59b1a63c233',1,'AttendanceStore']]],
  ['constructor_5',['constructor',['../class_attendance_store.html#ae754b4619dfb945c5e9be197d56f8cea',1,'AttendanceStore']]],
  ['courseid_6',['courseId',['../store_8js.html#ae2cf3bc09ea71584b06a372841edb72a',1,'store.js']]]
];
