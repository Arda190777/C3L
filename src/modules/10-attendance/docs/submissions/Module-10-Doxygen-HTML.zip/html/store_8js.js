var store_8js =
[
    [ "AttendanceStore", "class_attendance_store.html", "class_attendance_store" ],
    [ "courseId", "store_8js.html#ae2cf3bc09ea71584b06a372841edb72a", null ],
    [ "date", "store_8js.html#a17c42a345ea2516551cb82a290b8d586", null ],
    [ "import", "store_8js.html#a59be084da8908b7d77ff34b25cd84488", null ],
    [ "notes", "store_8js.html#afa3ea1aee547ae219afe39c9a87df442", null ],
    [ "status", "store_8js.html#a52780be446fa8721e1042a757dbe4615", null ],
    [ "studentId", "store_8js.html#a4ab28e41ef28c0de08cf3d772e1116f4", null ]
];